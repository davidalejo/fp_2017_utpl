def suma(num1, num2):

	suma = num1 + num2

	print ("La suma de "+ str(num1)+" más "+ str(num2) +" es igual a "+ str(suma))

def resta(num1, num2):

	resta = num1 - num2

	print ("La resta de "+ str(num1)+" menos "+ str(num2) +" es igual a "+ str(resta))


def multiplicacion(num1, num2):

	x = num1 * num2

	print ("La multiplicación de "+ str(num1)+" x "+ str(num2) +" es igual a "+ str(x))


def division(num1, num2):

	division = num1 / num2

	print ("La división de "+ str(num1)+" / "+ str(num2) +" es igual a "+ str("%.2f"%division))



def calculo(opcion,num1, num2):

	if (opcion == 1):
		suma(num1,num2)
	else:
		if (opcion == 2):
			resta(num1,num2)
		else:
			if (opcion == 3):
				multiplicacion(num1,num2)
			else:
				if (opcion == 4):
					division(num1,num2)


