def mayusculas(valor):
	print(valor.upper())

def minusculas(valor):
	print(valor.lower())

def impresion(opcion, valor):

    if (opcion == 1):
    	mayusculas(valor)
    else:
    	if(opcion == 2):
    		minusculas(valor)
    	else:
    		print("No hay reporte")
