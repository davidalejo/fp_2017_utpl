from Operacion import *

num1 = int(input("Ingrese primer numero: "))
num2 = int(input("Ingrese segundo numero: "))

print("(1)SUMA\n(2)RESTA\n(3)Multiplicación\n(4)División\n")

opcion = int(input("Selecione la operacion que desee : "))

calculo(opcion,num1,num2)