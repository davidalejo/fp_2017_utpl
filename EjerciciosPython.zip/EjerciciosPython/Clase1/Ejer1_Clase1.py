c = [0, 0, 0, 0, 0]

for i in range(len(c)):
    
    print("Posicion : ",i," valor :",c[i] ) 