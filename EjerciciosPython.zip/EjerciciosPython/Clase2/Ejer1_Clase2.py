n =4
b =[[0] * n for i in range (n)]
print (b) #[[0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0]]
print ()

for i in range (n):
    for j in range (n):  
        print (b[i][j]) # Imprime en vertical.
    