class Operacion3:
	def __init__(self):
		self.__lado = "" # Se declara la una variable privada con  doble espacio por delante __variable.

	def set_agregar_lado(self,valor_lado): # Metodo para agregar valores.
		self.__lado = valor_lado

	def get_obtener_lado(self): # Metodo para obtener valores
		return self.__lado # Se retorna la variable.
	# 
	def calcular_area(self): # Metodo para calcular area.

		area = int(self.__lado) * int(self.__lado) # Se llama la variable privada, cambiamos de str a int.
		
		return area # Se retorna la variable.

	def calcular_perimetro(self): # Metodo para calcular perimetro.

		perimetro = int(self.__lado) + int(self.__lado) + int(self.__lado) + int(self.__lado) # Se llama la variable privada, cambiamos de str a int.

		return perimetro # Se retorna la variable.