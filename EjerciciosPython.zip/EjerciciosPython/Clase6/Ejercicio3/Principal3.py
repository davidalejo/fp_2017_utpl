from Operacion3 import*

for i in range(4): 

	valor_lado = input("Agrese valor del cuadrado "+str(i+1) +"\n") 

	c = Operacion3() 

	c.set_agregar_lado(valor_lado)

	print("Cuadrado con lado "+ str(c.get_obtener_lado())+ "\n\tArea = " + str(c.calcular_area()) + "\n\tPerimetro =" + str(c.calcular_perimetro()))