c = [11, 22, 43, 14]
suma = 0
for i in range(len(c)):
    suma = suma + c[i]
    print("Posicion ",i,"valor ",c[i] )
print(suma)