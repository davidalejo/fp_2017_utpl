def generar_recibo(nombre,apellido, cedula, edad, sueldo_neto):

	descuento = obtener_descuento(sueldo_neto,edad)
	seguro = obtener_seguro(sueldo_neto)
	sueldo_final = sueldo_neto + seguro - descuento

	print("Recibo\n" + "nombre: "+  obtener_mayusculas(nombre) +"\t" +" Apellido: "+ apellido + "\nSueldo final: " + str("%.2f"%sueldo_final))

def obtener_descuento(sueldo_neto,edad):

	if(edad >= 50):
		d = sueldo_neto * 0.05
	else:
		d = sueldo_neto * 0.01
	return d

def obtener_seguro(sueldo_neto):

	s = sueldo_neto*0.15
	return s

def obtener_mayusculas(nombre):

	return (nombre.upper())
