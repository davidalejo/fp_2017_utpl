entrada = 1
clasificacion = ["Menores 18", ">= 18 y <= 25",">25"]
clases = []


while (entrada != 0) :

	edad = int(input("Ingrese las  edades : "))
	cero = 0
	clases.append(cero)

	if(edad <18):
		clases[0] = clases[0] + 1
	if(edad >= 18 and edad <= 25):
		clases[1] = clases[1] + 1
	if(edad > 25):
		clases[2] = clases[2] + 1
		
	off =int(input("Escriba 99 para salir"))

	if (off == 99):
		for i in range(len(clasificacion)):
			print("El numero de estudiantes del rango : "+str(clasificacion [i])+" es :"+str(clases[i]))
		break