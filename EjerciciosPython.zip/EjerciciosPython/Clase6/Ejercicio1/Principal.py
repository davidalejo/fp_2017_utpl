from Operaciones import *
suma_edades = 0
promedio = 0

e1 = Operaciones()
e2 = Operaciones()

e1.set_agregar_nombre("Luis")
e2.set_agregar_nombre("Maria") 

e1.set_agregar_edad("20")
e2.set_agregar_edad("17")

suma_edades = int(e1.get_obtener_edad()) + int(e2.get_obtener_edad())

promedio = (suma_edades/2)

print (promedio)