class Operaciones:
	def __init__(self):
		self.nombre = ""
		self.edad = ""

	def set_agregar_nombre(self,valor_nombre):
		self.nombre = valor_nombre
	def get_obtener_nombre(self):

		return self.nombre()

	def set_agregar_edad(self,edad):
		self.edad = edad
	def get_obtener_edad(self):
		return self.edad

