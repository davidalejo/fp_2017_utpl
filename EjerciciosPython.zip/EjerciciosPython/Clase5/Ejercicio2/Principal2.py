from Operaciones2 import *

nombre = "Luis"
apellido = "Romero"
cedula = "112334555"
edad = 40
sueldo_neto = 500.2

generar_recibo(nombre,apellido, cedula, edad, sueldo_neto)