b=[[1,2,3],[11,22,33]]

for i in range (len(b)):
   
    for j in range(len(b[i])):

        print (b[i][j],end="\t")
    print () 