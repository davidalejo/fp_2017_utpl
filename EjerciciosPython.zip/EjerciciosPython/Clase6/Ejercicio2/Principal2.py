from Operacion2 import *
e1 = Operacion2 ()
e2 = Operacion2 ()
edad1= "20"
edad2 = "17"

e1.set_agregar_edad(edad1)
e2.set_agregar_edad(edad2)
valor_nombre = "Ricardo"

e1.set_agregar_nombre(valor_nombre)
e2.set_agregar_nombre("Maria")

suma_edades = int(e1.get_obtener_edad()) + int(e2.get_obtener_edad())

promedio = (suma_edades/2)
print (promedio)
print (e2.get_obtener_nombre())