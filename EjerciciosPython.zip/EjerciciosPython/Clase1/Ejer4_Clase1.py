suma = 0
notas = []
materias = ["Programación", "Biologia", "Base de datos", "Contabilidad"]

for i in range(len(materias)):
    
    introducir = int(input("Notas de " + materias[i] + " es: "))
    notas.append(introducir)
print("-----------------------------------------------------------")
for i in range(len(materias)):

	print("La nota de la materia de "+ materias[i] + " fue de "+str(notas[i]))

print("-----------------------------------------------------------")
for i in range(len(notas)):
	suma = suma + notas[i]

promedio = suma / len(notas)
print("El promedio de las materias es: "+ str(promedio))


if (promedio >= 80):

	print("Sobresaliente")

if (promedio < 80 and  promedio > 60):

	print("Bueno")

if (promedio <= 60 ):

	print("Regular")
