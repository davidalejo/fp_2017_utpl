arreglo = [[7,7,8],[9,8,10],[10,10,3]]
estudiantes = [["Maria", "Loja"], ["Luis", "Quito"], ["Jose", "Cuenca"]]
promedios = []
suma = 0

for fila in range (len(arreglo)):

    for columna in range(len(arreglo[fila])):
  
        suma = suma + arreglo[fila][columna]
    promedio = suma / len(arreglo[fila])
    promedios.append(promedio)
    suma = 0

for fila in range (len(estudiantes)):
	print("Nombre : %s"%estudiantes[fila][0])
	print("Ciudad : %s"%estudiantes[fila][1])
	print ("Ciudad : %.2f\n" %promedios[fila])