from Presentacion1 import *

valor = str(input("Ingrese su nombre : "))
opcion = int(input("Tipo de reporte 1 o 2: "))

impresion(opcion,valor)
