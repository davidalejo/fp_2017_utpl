from Operaciones import *

tam_notas = [1,2,3]
notas = []
suma = 0


nombre = str(input("Ingrese su nombre: "))
apellido = str(input("Ingrese sus apellidos: "))
ciudad = str(input("Ingrese su ciudad: "))
edad = int(input("Ingrese su edad: "))

for i in range(len(tam_notas)):
    
    introducir = int(input("Nota " + str(i +1) + " es: "))
    notas.append(introducir)


for i in range(len(notas)):
	suma = suma + notas[i]


imprime_libreta(nombre,apellido,ciudad,edad,suma)