from Operaciones import*
estudiantes = ["Estudiante1", "studiante2", "Estudiante3", "Estudiante4", "Estudiante5", "Estudiante6", "Estudiante7", "Estudiante8", "Estudiante9", "Estudiante10", "Estudiante11", "Estudiante12", "Estudiante13", "Estudiante14", "Estudiante15"]
notas = []
suma = 0

for columna in range(len(estudiantes)):
	notas1 = input("Ingrese calificacion final:\n")
	notas.append(notas1)

for columna in range(len(notas)):
	suma = suma + int(notas[columna])

promedio = suma /len(notas)
print("Promedio de de calificaciones es: "+ str(promedio))
print("\nSe determina que el curso esta en el rango: ")

determinar(promedio)