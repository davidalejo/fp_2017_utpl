def determinar(promedio):

	if(promedio >= 90):
		print("\tSOBRESALIENTE")
	else:
		if(promedio >= 70 and promedio < 90):
			print("\tMUY BUENO")
		else:
			if(promedio > 45 and promedio < 70):
				print("\tBUENO")
			else:
				if(promedio < 45):
					print("\tREGULAR")

