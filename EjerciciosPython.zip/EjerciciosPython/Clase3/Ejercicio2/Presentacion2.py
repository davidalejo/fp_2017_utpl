from Presentacion1 import *

valor = str(input("Ingrese su nombre: "))
opcion = int(input("Elija opcion 1 o 2: "))


if (opcion == 1):
    mayusculas(valor)
else:
    if(opcion == 2):
    	minusculas(valor)
    else:
    	print("No hay reporte")