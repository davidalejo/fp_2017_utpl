import pilasengine
pilas = pilasengine.iniciar()
pilas.actores.Sonido()
fin_de_Juego = False
fondo = pilas.fondos.Espacio()
puntos = pilas.actores.Puntaje( x=-280, y=200, color= pilas.colores.blanco)
nave = pilas.actores.Nave( y= -200)

# Creacion de la nave principal
nave.aprender('limitadoabordesdepantalla')

disparo_de_nave = pilasengine.actores.Misil

nave.aprender('disparar', municion = disparo_de_nave , angulo_salida_disparo = 90, frecuencia_de_disparo = 2)

nave.aprender('puedeexplotar')

nave.aprender('moverseconelteclado')

# Creacion del ovni, movimientos, disparos

def crear_ovni():
	enemigo1 = pilas.actores.Ovni( y = 200)
	enemigo1.radio_de_colision=25
	enemigo1.aprender('puedeexplotar')
	disparo_de_enemigo1 = pilasengine.actores.Bomba
	enemigo1.aprender('disparar', control=None, municion = disparo_de_enemigo1 , angulo_salida_disparo = 270, frecuencia_de_disparo = 0.5, escala = 0.5)
	
	def mover_ovni():	
		enemigo1.x = [0, -300, 300], 3

	pilas.tareas.agregar(0.5, mover_ovni)
	pilas.tareas.siempre(9.5, mover_ovni)

	def dispara():
		enemigo1.disparar()
		return True

	enemigo1.tarea_dispara = pilas.tareas.agregar(1, dispara)
crear_ovni()
# Creacion las aceitunas aparicion
def crear_enemigo():
	enemigo2 = pilas.actores.Aceituna()
	enemigo2.aprender('puedeexplotarconhumo')
	enemigo2.aprender(pilas.habilidades.Disparar, control=None, angulo_salida_disparo = 270, frecuencia_de_disparo = 0.5, escala = 0.5)
	enemigo2.x = pilas.azar(-200, 200)
	enemigo2.y = pilas.azar(-100, 150)
	

	if fin_de_Juego:
		return False
	else: 
		return True
pilas.tareas.siempre(1, crear_enemigo)


## Eliminar aceitunas 

def destruir(disparo, enem):
	disparo.eliminar()
	enem.eliminar()
	pilas.avisar("Bien Hecho")
	# Puntos aumentan
	puntos.aumentar(50)

	
## Disparar al ovni
def destruir_ovni(misil,ovni):
	crear_ovni()
        misil.eliminar()
	ovni.eliminar()
	pilas.avisar("Doble Puntaje")
	ovni.tarea_dispara.eliminar()
	# Puntos aumentan
	puntos.aumentar(100)

def perder(nav, ene):
	nav.eliminar()
	pilas.tareas.eliminar_todas()
	fin_de_Juego = True

	pilas.avisar("Perdiste")

# Colisiones

pilas.colisiones.agregar('Nave', 'Aceituna', perder)
pilas.colisiones.agregar('Nave', 'Bomba', perder)
pilas.colisiones.agregar('Misil', 'Aceituna', destruir)
pilas.colisiones.agregar('Misil', 'Ovni', destruir_ovni)

pilas.ejecutar()