arreglo=[[7,7,8],[9,8,10],[10,10,3]]
suma = 0

for fila in range (len(arreglo)):

    for columna in range(len(arreglo[fila])):
        print (arreglo[fila][columna],end="\t")
        suma = suma + arreglo[fila][columna]
    promedio = suma / len(arreglo[fila])
    suma = 0
    print ("Promedio\t %.2f"% promedio)
    print ()