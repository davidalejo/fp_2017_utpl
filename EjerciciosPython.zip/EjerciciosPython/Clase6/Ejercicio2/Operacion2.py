class Operacion2:
	def __init__(self):
		self.__nombre = ""
		self.__edad = ""

	def set_agregar_nombre(self,valor_nombre):
		self.__nombre = valor_nombre
	def get_obtener_nombre(self):

		return self.__nombre.upper()

	def set_agregar_edad(self,edad):
		self.__edad = edad
	def get_obtener_edad(self):
		return self.__edad

