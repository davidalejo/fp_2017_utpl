suma = 0
partidos = []
dias = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"]

for i in range(len(dias)):
    
    introducir = int(input("Número de partidos jugados el día : " + dias[i] + " es: "))
    partidos.append(introducir)
print("-----------------------------------------------------------")
for i in range(len(dias)):

	print("El numero de partidos jugados el día : "+ dias[i] + " fue de : "+str(partidos[i]))

print("-----------------------------------------------------------")
for i in range(len(partidos)):
	suma = suma + partidos[i]

promedio = suma / len(partidos)
print("El promedio de los partidos jugados es de : "+ str(promedio))