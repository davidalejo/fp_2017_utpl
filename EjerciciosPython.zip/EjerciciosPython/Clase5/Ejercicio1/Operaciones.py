def imprime_libreta(nombre,apellido,ciudad,edad,suma):
	promedio = obtener_promedio(suma)
	apellido_minus = obtener_minusculas(apellido)
	ciudad = obtener_mayusculas(ciudad)
	equi = obtener_equivalencias(promedio)
	print("Nombre: " + str(nombre) + "\nApellido : "+ str(apellido_minus) +"\nEdad :" + str(edad) + "\nCiudad : " + str(ciudad) + "\nEl promedio es de : " + str(promedio) + "con una puntuacion : " + str(equi))


def obtener_promedio(suma):

	promedio = suma/3
	return promedio

def obtener_minusculas(apellido):
	return (apellido.lower())
def obtener_mayusculas(ciudad):
	return (ciudad.upper())
def obtener_equivalencias(promedio):


	if(promedio >= 90):
		equi = "Sobresaliente"
	else:
		if(promedio >= 50 and promedio < 90):
			equi = "Muy bueno"
		else:
			if(promedio < 50):
				equi = "Bueno"
	return equi
